class AccountsController < ApplicationController
	def new
	end
end
