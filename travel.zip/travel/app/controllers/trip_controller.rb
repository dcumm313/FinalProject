class TripController < ApplicationController
  def index
  end
  def sign_up
  end
end
