class Trip < ApplicationRecord
	attr_accessible :address, :distance, :latitude, :longitude
	geocoded_by :address
	after_validation :geocode
end
