module TripHelper
end
