require 'geocoder/results/google'

module Geocoder::Result
  class GooglePremier < Google
  end
end