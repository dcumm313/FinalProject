require 'geocoder/results/nominatim'

module Geocoder::Result
  class LocationIq < Nominatim
  end
end