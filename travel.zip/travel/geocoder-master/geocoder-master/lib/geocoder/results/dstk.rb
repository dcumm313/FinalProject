require 'geocoder/results/google'

module Geocoder::Result
  class Dstk < Google
  end
end