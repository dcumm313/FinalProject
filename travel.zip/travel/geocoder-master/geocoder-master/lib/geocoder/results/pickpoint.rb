require 'geocoder/results/nominatim'

module Geocoder::Result
  class Pickpoint < Nominatim
  end
end