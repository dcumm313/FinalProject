require 'geocoder/results/pelias'

module Geocoder::Result
  class Mapzen < Pelias; end
end
