module Geocoder
  VERSION = "1.4.7"
end
