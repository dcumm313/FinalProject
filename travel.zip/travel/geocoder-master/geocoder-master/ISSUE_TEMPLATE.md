BEFORE POSTING AN ISSUE, PLEASE MAKE SURE THE PROBLEM IS NOT ADDRESSED IN THE README!

### Expected behavior



### Actual behavior



### Steps to reproduce



### Environment info

* Geocoder version: 
* Rails version: 
* Database (if applicable): 
* Lookup (if applicable): 
