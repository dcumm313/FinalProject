Rails.application.routes.draw do
  get 'trip/index'
  
  root 'trip#index'
end
