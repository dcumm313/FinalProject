class CreateTrips < ActiveRecord::Migration[5.2]
  def change
    create_table :trips do |t|
      t.float :distance
      t.string :destination
      t.string :title

      t.timestamps
    end
  end
end
